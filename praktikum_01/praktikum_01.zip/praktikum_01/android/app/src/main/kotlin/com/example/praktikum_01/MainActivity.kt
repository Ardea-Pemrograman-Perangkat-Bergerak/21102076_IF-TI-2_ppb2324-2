package com.example.praktikum_01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
